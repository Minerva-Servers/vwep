vwep.util:IncludeDir("weapons/vwep_base/core")

// Information
SWEP.PrintName = "Vanguard Weapon Base" // Weapon name in the HUD
SWEP.Author = "Riggs" // Author
SWEP.Instructions = "Left click to shoot, right click to zoom." // Instructions
SWEP.Category = "Vanguard" // Category in the spawn menu
SWEP.IsVWEP = true // Mark this as a Vanguard Weapon Base Weapon, useful for other scripts

// Weapon settings
SWEP.Slot = 1 // Slot in the weapon selection menu
SWEP.SlotPos = 1 // Slot position
SWEP.DrawAmmo = true // Draw the ammo count
SWEP.DrawCrosshair = true // Draw the crosshair
SWEP.DrawWeaponInfoBox = false // Draw the weapon info box

// Base weapon settings
SWEP.Spawnable = false // Can be spawned via the Q menu
SWEP.AdminOnly = false // Admin only spawn

// Secondary gun settings, unused for now
SWEP.Secondary.ClipSize = -1 // No secondary clip
SWEP.Secondary.DefaultClip = -1 // No secondary default clip
SWEP.Secondary.Automatic = false // Secondary fire automatic?
SWEP.Secondary.Ammo = "none" // No secondary ammo
SWEP.Secondary.Delay = 0.5 // Secondary fire delay

// Weapon settings
SWEP.HoldType = "pistol" // Weapon hold type
SWEP.UseHands = true // Use hands model
SWEP.Sensitivity = 1 // Sensitivity when not aiming

// Primary gun settings
SWEP.Primary.ClipSize = 18 // Size of a clip
SWEP.Primary.DefaultClip = 18 // Default number of bullets in a clip
SWEP.Primary.Automatic = false // Is this weapon automatic
SWEP.Primary.Ammo = "Pistol" // Type of ammo

// Primary fire settings
SWEP.Primary.Recoil = 1 // Recoil effect
SWEP.Primary.Damage = 10 // Damage per shot
SWEP.Primary.NumShots = 1 // Number of shots per trigger pull
SWEP.Primary.Cone = 0.02 // Bullet spread
SWEP.Primary.Delay = 0.5 // Delay between shots
SWEP.Primary.RPM = 400 // Rounds per minute, this is used instead of delay if it's set
SWEP.Primary.Sequence = ACT_VM_PRIMARYATTACK // The shoot animation
SWEP.Primary.SequenceIronSights = ACT_VM_PRIMARYATTACK // The shoot animation when iron sighting
SWEP.Primary.PlaybackRate = 1 // The playback rate of the shoot animation

// Primary sound settings
SWEP.Primary.Sound = Sound("Weapon_Pistol.Single") // Primary fire
SWEP.Primary.SoundEmpty = Sound("Weapon_Pistol.Empty") // Primary fire when empty
SWEP.Primary.SoundLevel = 100 // Sound level, used for sound distance
SWEP.Primary.SoundPitch = 100 // Sound pitch
SWEP.Primary.SoundVolume = 1 // Sound volume
SWEP.Primary.SoundChannel = CHAN_WEAPON // Sound channel

// Iron sights settings
SWEP.IronSightsEnabled = true // Enable iron sights
SWEP.IronSightsPos = Vector(-5.95, -9.2, 2.7) // Iron sights position
SWEP.IronSightsAng = Vector(2.6, 1.37, 3.5) // Iron sights angle
SWEP.IronSightsFOV = 0.75 // Iron sights field of view
SWEP.IronSightsSensitivity = 0.5 // Iron sights sensitivity
SWEP.IronSightsCanMove = true // Can the player iron sight while moving?
SWEP.IronSightsCanMoveRun = false // Can the player iron sight while running?
SWEP.IronSightsRunSpeed = 0.75 // Check if the player is marked as running at this speed
SWEP.IronSightsToggle = false // Is the iron sight a toggle mechanism, mark as false if it's a hold mechanism

// Reloading settings
SWEP.Reloading = {}
SWEP.Reloading.Sequence = ACT_VM_RELOAD // The reload animation
SWEP.Reloading.SequenceIronSights = ACT_VM_RELOAD // The reload animation when iron sighting
SWEP.Reloading.PlaybackRate = 1 // The playback rate of the reload animation
SWEP.Reloading.Sound = Sound("Weapon_Pistol.Reload") // The reload sound
SWEP.Reloading.SoundLevel = 60 // The reload sound level, used for sound distance
SWEP.Reloading.SoundPitch = 100 // The reload sound pitch
SWEP.Reloading.SoundVolume = 1 // The reload sound volume
SWEP.Reloading.SoundChannel = CHAN_WEAPON // The reload sound channel

// Cycling settings
SWEP.Cycling = {}
SWEP.Cycling.Enabled = false // Enable cycling
SWEP.Cycling.Ammo = 1 // The ammo to give when cycling
SWEP.Cycling.SequenceEntry = nil // The cycling entry animation
SWEP.Cycling.Sequence = ACT_VM_RELOAD // The cycling animation
SWEP.Cycling.SequenceExit = nil // The cycling exit animation
SWEP.Cycling.SequenceIronSightsEntry = nil // The cycling entry animation when iron sighting
SWEP.Cycling.SequenceIronSights = ACT_VM_RELOAD // The cycling animation when iron sighting
SWEP.Cycling.SequenceIronSightsExit = nil // The cycling exit animation when iron sighting
SWEP.Cycling.PlaybackRate = 1 // The playback rate of the cycling animation
SWEP.Cycling.Sound = Sound("Weapon_Pistol.Reload") // The cycling sound
SWEP.Cycling.SoundLevel = 60 // The cycling sound level, used for sound distance
SWEP.Cycling.SoundPitch = 100 // The cycling sound pitch
SWEP.Cycling.SoundVolume = 1 // The cycling sound volume
SWEP.Cycling.SoundChannel = CHAN_WEAPON // The cycling sound channel
SWEP.Cycling.Delay = 0.5 // The delay between cycling
SWEP.Cycling.Automatic = false // Is the cycling automatic?

// Pump action settings
SWEP.PumpAction = {}
SWEP.PumpAction.Enabled = false // Enable pump action
SWEP.PumpAction.Sequence = ACT_SHOTGUN_PUMP // The pump action animation
SWEP.PumpAction.SequenceIronSights = ACT_SHOTGUN_PUMP // The pump action animation when iron sighting
SWEP.PumpAction.PlaybackRate = 1 // The playback rate of the pump action animation
SWEP.PumpAction.Sound = Sound("Weapon_Shotgun.Special1") // The pump action sound
SWEP.PumpAction.SoundLevel = 60 // The pump action sound level, used for sound distance
SWEP.PumpAction.SoundPitch = 100 // The pump action sound pitch
SWEP.PumpAction.SoundVolume = 1 // The pump action sound volume
SWEP.PumpAction.SoundChannel = CHAN_WEAPON // The pump action sound channel

// Viewmodel settings
SWEP.ViewModel = "models/weapons/c_pistol.mdl" // The model used in first-person view
SWEP.ViewModelSkin = 0 // Viewmodel skin
SWEP.ViewModelBodygroups = {} // Viewmodel bodygroups
SWEP.ViewModelFOV = 62 // Viewmodel field of view
SWEP.ViewModelFlip = false // Flip the viewmodel
SWEP.ViewModelOffset = Vector(0, 0, 0) // Viewmodel offset
SWEP.ViewModelOffsetAng = Angle(0, 0, 0) // Viewmodel angle offset
SWEP.ViewModelScale = 1 // Viewmodel scale
SWEP.ViewModelDynamicLights = {
    --{Pos = Vector(0, 0, 0), Brightness = 1, Size = 1, Decay = 100, Color = Color(255, 255, 255, 255)} // Example
}

SWEP.ViewModelMaterial = "" // Viewmodel material
SWEP.ViewModelColor = Color(255, 255, 255, 255) // Viewmodel color
SWEP.ViewModelRenderMode = RENDERMODE_NORMAL // Viewmodel render mode
SWEP.ViewModelRenderFX = kRenderFxNone // Viewmodel render fx

// Worldmodel settings
SWEP.WorldModel = "models/weapons/w_pistol.mdl" // The model used in third-person view
SWEP.WorldModelSkin = 0 // Worldmodel skin
SWEP.WorldModelBodygroups = {} // Worldmodel bodygroups
SWEP.WorldModelBone = "ValveBiped.Bip01_R_Hand" // The bone to attach the worldmodel to
SWEP.WorldModelOffset = Vector(0, 0, 0) // Worldmodel offset
SWEP.WorldModelOffsetAng = Angle(0, 0, 0) // Worldmodel angle offset
SWEP.WorldModelScale = 1 // Worldmodel scale
SWEP.WorldModelDynamicLights = {
    --{Pos = Vector(0, 0, 0), Brightness = 1, Size = 1, Decay = 100, Color = Color(255, 255, 255)} // Example
}

SWEP.WorldModelMaterial = "" // Worldmodel material
SWEP.WorldModelColor = Color(255, 255, 255, 255) // Worldmodel color
SWEP.WorldModelRenderMode = RENDERMODE_NORMAL // Worldmodel render mode
SWEP.WorldModelRenderFX = kRenderFxNone // Worldmodel render fx

// Weapon effects
SWEP.Effects = {}
SWEP.Effects.MuzzleFlash = true // Enable muzzle flash
SWEP.Effects.MuzzleFlashEffect = "MuzzleFlash" // Muzzle flash effect
SWEP.Effects.MuzzleFlashFlags = 1 // Muzzle flash flags
SWEP.Effects.MuzzleFlashScale = 1 // Muzzle flash scale
SWEP.Effects.MuzzleFlashAttachment = "muzzle" // Muzzle flash attachment

SWEP.Effects.Tracer = true // Enable tracer
SWEP.Effects.TracerEffect = "Tracer" // Tracer effect
SWEP.Effects.TracerScale = 1 // Tracer scale
SWEP.Effects.TracerAttachment = "muzzle" // Tracer attachment

function SWEP:SetupDataTables()
    if ( self.PreSetupDataTables ) then
        self:PreSetupDataTables()
    end

    self:NetworkVar("Bool", 0, "IronSights")
    self:NetworkVar("Bool", 1, "Reloading")
    self:NetworkVar("Float", 0, "NextIdle")

    if ( self.PostSetupDataTables ) then
        self:PostSetupDataTables()
    end
end

function SWEP:Initialize()
    if ( self.PreInitialize ) then
        self:PreInitialize()
    end

    self:SetWeaponHoldType(self.HoldType)
    self:SetIronSights(false)

    if ( self.PostInitialize ) then
        self:PostInitialize()
    end
end

function SWEP:QueueIdle(duration)
    local vm = self:GetOwner():GetViewModel()
    if ( !IsValid(vm) ) then return end

    duration = duration or vm:SequenceDuration() / vm:GetPlaybackRate()
    duration = math.Round(duration, 2)
    duration = duration + 0.1

    self:SetNextIdle(CurTime() + duration)
end

function SWEP:SecondaryAttack()
    if ( !IsFirstTimePredicted() ) then return end
    if ( !self:CanSecondaryAttack() ) then return end

    if ( self.PreSecondaryAttack ) then
        self:PreSecondaryAttack()
    end

    self:SetNextSecondaryFire(CurTime() + self.Secondary.Delay)

    if ( self.PostSecondaryAttack ) then
        self:PostSecondaryAttack()
    end
end

function SWEP:ThinkIdle()
    if ( !self:GetNextIdle() ) then
        self:SetNextIdle(0)
    end

    if ( self:GetNextIdle() <= 0 ) then return end

    if ( CurTime() > self:GetNextIdle() ) then
        self:SetNextIdle(0)
        self:PlayAnimation(self:Clip1() > 0 and ( self.IdleAnim or ACT_VM_IDLE ) or ( self.EmptyAnim or ACT_VM_IDLE_EMPTY ))
    end
end

function SWEP:Think()
    local ply = self:GetOwner()
    if ( !IsValid(ply) ) then return end

    self:ThinkIronSights()
    self:ThinkIdle()
end

function SWEP:Deploy()
    if ( self.PreDeploy ) then
        self:PreDeploy()
    end

    self:SetIronSights(false)
    self:SetReloading(false)
    self:SetNextIdle(0)

    self:PlayAnimation(self.DeployAnim or ACT_VM_DRAW)
    self:QueueIdle()

    if ( self.PostDeploy ) then
        self:PostDeploy()
    end

    return true
end

function SWEP:Holster()
    if ( self.PreHolster ) then
        self:PreHolster()
    end

    self:SetIronSights(false)
    self:SetReloading(false)
    self:SetNextIdle(0)

    if ( self.PostHolster ) then
        self:PostHolster()
    end

    return true
end